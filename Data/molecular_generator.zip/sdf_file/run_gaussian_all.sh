#!/bin/bash

#SBATCH -J test              # 作业名称
#SBATCH -p C6326CHEN         # 分区/队列名称
#SBATCH -o %j.log            # 标准输出日志文件（以作业ID命名）
#SBATCH -e %j.log            # 标准错误日志文件（以作业ID命名）
#SBATCH --ntasks=1           # 单任务作业
#SBATCH --cpus-per-task=8    # 每任务分配的 CPU 核数
#SBATCH --nodes=1            # 使用的节点数
#SBATCH --mem=20G            # 每任务所需内存

ulimit -s unlimited
echo $SLURM_JOB_ID > ./jobid

module load gaussian/g16

# 查找当前目录及子目录下所有优化计算用的 .gjf 文件（以 _opt.gjf 结尾）
opt_files=($(find . -type f -name "*_opt.gjf"))

for opt_file in "${opt_files[@]}"; do
  # 获取分子名称（去掉 "_opt.gjf" 后缀）
  molecule_name="${opt_file%_opt.gjf}"

  # 创建结构优化计算目录
  opt_dir="${molecule_name}_opt"
  mkdir -p "$opt_dir"

  # 复制优化计算所需文件
  cp "$opt_file" "$opt_dir/"
  #cp run.gaussian.sh "$opt_dir/"

  # 进入优化计算目录
  cd "$opt_dir"

  # 运行 Gaussian 进行结构优化
  g16 < "$(basename "$opt_file")" > opt_output.log

  for inf in *.chk
  do
  formchk ${inf}
  done  

  # 检查是否生成了 .chk 文件
  chk_file="${molecule_name}.chk"
  if [ -f "$chk_file" ]; then
    echo "Optimization completed for $molecule_name, chk file found: $chk_file"
  else
    echo "Optimization failed for $molecule_name, skipping volume calculation."
    cd ..
    continue  # 跳过该分子的体积计算
  fi

  # 返回上级目录
  cd ..

  # 体积计算的 .gjf 文件（应以 _vol.gjf 结尾）
  vol_file="${molecule_name}_vol.gjf"
  if [ -f "$vol_file" ]; then
    # 创建体积计算目录
    vol_dir="${molecule_name}_vol"
    mkdir -p "$vol_dir"

    # 复制体积计算所需文件
    cp "$vol_file" "$vol_dir/"
    cp "$opt_dir/$chk_file" "$vol_dir/"
    #cp run.gaussian.sh "$vol_dir/"

    # 进入体积计算目录
    cd "$vol_dir"

    # 运行 Gaussian 进行分子体积计算
    g16 < "$(basename "$vol_file")" > vol_output.log

    for inf in *.chk
    do
    formchk ${inf}
    done

    # 体积计算完成
    echo "Volume calculation completed for $molecule_name."

    # 返回上级目录
    cd ..
  else
    echo "Volume calculation input file missing for $molecule_name, skipping."
  fi
done

