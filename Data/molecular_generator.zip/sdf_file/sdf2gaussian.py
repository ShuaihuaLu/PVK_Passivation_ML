import ase.io
import os

def create_gaussian_input(sdf_file, gjf_file, chk_file, method='b3lyp', basis='6-31g*',
                          charge=0, mult=1, mem=8, nproc=4, calc_type="opt freq"):
    """
    生成 Gaussian 输入文件 (gjf)，用于结构优化或体积计算。

    参数：
        sdf_file (str): 输入 SDF 文件路径。
        gjf_file (str): 生成的 Gaussian 输入文件路径。
        chk_file (str): 共享的 .chk 文件路径，优化计算与体积计算应使用相同的 chk 文件。
        method (str): 计算方法（默认：'b3lyp'）。
        basis (str): 基组（默认：'6-31g*'）。
        charge (int): 分子电荷（默认：0）。
        mult (int): 自旋多重度（默认：1）。
        mem (int): 内存大小（GB，默认：8）。
        nproc (int): 使用的 CPU 核数（默认：4）。
        calc_type (str): 计算类型（"opt freq" 或 "sp volume"）。
    """
    # 读取 SDF 文件
    atoms = ase.io.read(sdf_file, format='sdf')

    # 生成 Gaussian 输入文件内容
    content = [
        f"%mem={mem}GB",
        f"%nprocshared={nproc}",
        f"%chk={chk_file}",
        f"# {calc_type} {method}/{basis}",
        "",
        f"{'Structure optimization' if 'opt' in calc_type else 'Molecular volume calculation'}",
        "",
        f"{charge} {mult}"
    ]

    # 添加原子坐标
    for atom in atoms:
        x, y, z = atom.position
        content.append(f"{atom.symbol} {x:.6f} {y:.6f} {z:.6f}")

    content.append("\n")  # 末尾空行

    # 写入 Gaussian 输入文件
    with open(gjf_file, 'w') as f:
        f.write('\n'.join(content))


def batch_process_sdf(sdf_dir, output_dir, method='b3lyp', basis='6-31g*',
                      charge=0, mult=1, mem=8, nproc=4):
    """
    批量处理 SDF 文件，生成 Gaussian 计算输入文件：
      1. 生成结构优化 (`*_opt.gjf`) 计算输入文件。
      2. 生成体积计算 (`*_vol.gjf`) 输入文件，使用优化后的 `.chk` 文件。

    参数：
        sdf_dir (str): SDF 文件所在目录。
        output_dir (str): 存放 Gaussian 输入文件的目录。
        method (str): 计算方法（默认：'b3lyp'）。
        basis (str): 基组（默认：'6-31g*'）。
        charge (int): 分子电荷（默认：0）。
        mult (int): 自旋多重度（默认：1）。
        mem (int): 内存大小（GB，默认：8）。
        nproc (int): 使用的 CPU 核数（默认：4）。
    """
    os.makedirs(output_dir, exist_ok=True)

    for sdf_file in os.listdir(sdf_dir):
        if sdf_file.endswith('.sdf'):
            sdf_path = os.path.join(sdf_dir, sdf_file)

            # 获取分子名称
            molecule_name = os.path.splitext(sdf_file)[0]
            chk_file = os.path.join(output_dir, f"{molecule_name}.chk")

            # 生成结构优化计算输入文件
            gjf_file_opt = os.path.join(output_dir, f"{molecule_name}_opt.gjf")
            create_gaussian_input(sdf_path, gjf_file_opt, chk_file, method, basis, charge, mult, mem, nproc, "opt freq")
            print(f"Created optimization input file: {gjf_file_opt}")

            # 生成体积计算输入文件，使用优化计算的 .chk 文件
            gjf_file_vol = os.path.join(output_dir, f"{molecule_name}_vol.gjf")
            create_gaussian_input(sdf_path, gjf_file_vol, chk_file, method, basis, charge, mult, mem, nproc, "geom=allcheck volume iop(6/45=2000)")
            print(f"Created volume calculation input file: {gjf_file_vol}")


if __name__ == "__main__":
    sdf_directory = './sdf_files'  # SDF 文件所在路径
    output_directory = './'  # 计算输入文件存放路径

    batch_process_sdf(
        sdf_dir=sdf_directory,
        output_dir=output_directory,
        method='b3lyp',
        basis='6-31g*',
        charge=0,
        mult=1,
        mem=20,
        nproc=8
    )

